## ------------------------------------------------------------------------
library(summaryTools)

## ------------------------------------------------------------------------
exampleData <- c(5, 9, 11, 13, NA, 2, 4, 8, 3)
stats <- numericSummary(exampleData)
stats

## ----, fig.show='hold'---------------------------------------------------
plot(exampleData)
abline(h = stats["Mean"], col = "grey", lty = 2)

