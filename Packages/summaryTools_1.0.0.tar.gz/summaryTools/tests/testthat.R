library(testthat)
library(summaryTools)

test_check("summaryTools")
