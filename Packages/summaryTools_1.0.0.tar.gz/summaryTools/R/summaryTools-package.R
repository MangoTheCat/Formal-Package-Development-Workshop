#' summaryTools: A package for generating standard numeric summaries
#'
#' This package will allow you to generate a standard set of summary statistics 
#' for vectors of data and has been designed for the purpose of demonstrating 
#' package building methods and structure. 
#'
#' @docType package
#'@name summaryTools
NULL